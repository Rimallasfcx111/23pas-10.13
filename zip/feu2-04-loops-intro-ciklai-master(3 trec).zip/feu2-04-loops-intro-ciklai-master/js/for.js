'use strict';
console.log('for.js');

/* 
for (init; salyga; zingsnis) {
  // ciklo body
}
init = viena karta
salyga, zingsnis = kaskarta
*/

// atspausdinti as esu for 10 kartu

for (let i = 0; i <= 10; i++) {
  console.log(i, 'as esu for');
}

// 1. atspausdinti skaicius nuo 14 iki 35

// 2. atspausdinti skaicius nuo 0 iki 100, kas trecia skaiciu

// 3. atspausdinti skaicius nuo 50 iki 24
