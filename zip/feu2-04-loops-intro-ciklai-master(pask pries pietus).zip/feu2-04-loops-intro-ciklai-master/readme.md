## uzd

1. atspausdinti skaicius nuo 14 iki 35

2. atspausdinti skaicius nuo 0 iki 100, kas trecia skaiciu

3. atspausdinti skaicius nuo 50 iki 24

4. atspausdinti 15 random verciu nuo 1 iki 10
4.1 atspausdinti verciu vidurki

5. atspausdinti nuo 47 iki 68 visus lyginius skaicius

6. sudeti visus skaicius nuo 0 iki 10, atspusdinti rezultata
