'use strict';
console.log('while.js');

// atspausdinti as esu while 10 kartu

let sp = 'as esu while';

let i = 1;

while (i < 11) {
  // ciklo body
  console.log('kazka');
  // step
  // i = i + 1
  // i += 1;
  i++;
}

// 1. atspausdinti skaicius nuo 14 iki 35

// 2. atspausdinti skaicius nuo 0 iki 100, kas trecia skaiciu

// 3. atspausdinti skaicius nuo 50 iki 24
