## uzd

1. atspausdinti skaicius nuo 14 iki 35

2. atspausdinti skaicius nuo 0 iki 100, kas trecia skaiciu

3. atspausdinti skaicius nuo 50 iki 24

4. atspausdinti 15 random verciu nuo 1 iki 10
4.1 atspausdinti verciu vidurki

5. atspausdinti nuo 47 iki 68 visus lyginius skaicius

6. sudeti visus skaicius nuo 0 iki 10, atspusdinti rezultata

7. sugeneruoti stringa kuris turetu tokia struktura:
   ```html
  <ul>
    <li>4</li>
    <li>5</li>
    <li>6</li>
  </ul>
   ```


8. Suskaiciuoti kiek skaiciau 4 kartotiniu nuo 0 iki 160

9. Surasyti i kintamaji myString visus skaicius nuo -10 iki 35 atskirtus kableliu ir tarpu
    pvz, -10, -9, -8, ....

<!-- psiaudo kodas 
1. susikuriu kintamaji myString prisilyginti tusciom kabutem
2. sukurti cikla kuris sukasi su skaiciais nuo -10 iki 35
3. sukant cikla kiekviena reiksme pridedu prie myString ir pridedu ", "
4. po ciklu atspausdinti myString
5. extra paskutinis elementas neturetu tureti kablelcio ir tarpelio.
 -->

10. Sudeti skaicius nuo 10 iki 20. 
    1.  sudedant atspausdinti kievieno zingsnio informacija
      pvz "Ciklo numeris 1, prie 0 pridedu 10 ir gaunu 10"
      pvz "Ciklo numeris 2, prie 10 pridedu 11 ir gaunu 21"
      pvz "Ciklo numeris 3, prie 21 pridedu 12 ir gaunu 33"
      ....
    2. atspausdinti galutini rezultata

11. sukuriam kintamji aukstis = 5. Panaudojus kintamji aukstis nupiesti eglute su tiek liniju kiek yra aukstis. (naudojant repeat() metoda ir be repeat metodo).
```
         +
        +++
       +++++
      +++++++
     +++++++++
```

12. atspausdinti consoleje 3 random reiksmes su 2 skaiciais po kablelio li taguose
    <li>2.48</li>
    <li>5.82</li>
    <li>9.40</li>

13. atspausdinti konsoleje skaicius nuo 12 iki 24 padaugintus is 3

14. atspausdinti konsoleje skaicius nuo 3 iki 25, jei skaicius lyginis prirasyti prie jo zodeli 'lyginis' pvz 
3
4 lyginis
5 
6 lyginis
....
14.1 prideti dar prie skaiciu kurie yra 3 kartotiniai 'triju kartotinis'
pvz 
3 triju kartotinis
4 lyginis
5 triju kartotinis
6 lyginis
....